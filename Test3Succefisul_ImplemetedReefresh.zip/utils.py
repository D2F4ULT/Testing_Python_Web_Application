from collections import Counter
import math

def calculate_frequencies(spins):
    number_freq = Counter(spins)
    total = len(spins)
    color_freq = {'red': 0, 'black': 0, 'green': 0}
    for n in spins:
        if n == 0:
            color_freq['green'] += 1
        elif n % 2 == 1:
            color_freq['red'] += 1
        else:
            color_freq['black'] += 1
    number_freq_pct = {k: v / total * 100 for k, v in number_freq.items()} if total > 0 else {}
    color_freq_pct = {k: v / total * 100 for k, v in color_freq.items()} if total > 0 else {}
    return number_freq_pct, color_freq_pct

def calculate_entropy(spins):
    total = len(spins)
    if total == 0:
        return 0.0
    counts = Counter(spins)
    entropy = 0.0
    for count in counts.values():
        p = count / total
        entropy -= p * math.log2(p)
    return entropy

def simulate_martingale(spins, initial_bankroll=1000, base_bet=10):
    bankroll = initial_bankroll
    bet = base_bet
    bankroll_history = []
    for n in spins:
        if n == 0 or n % 2 == 0:
            bankroll -= bet
            bet *= 2
        else:
            bankroll += bet
            bet = base_bet
        if bankroll <= 0:
            bankroll = 0
            bankroll_history.append(bankroll)
            break
        bankroll_history.append(bankroll)
    return bankroll_history
