import sqlite3
from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from utils import calculate_frequencies, calculate_entropy, simulate_martingale
import json
from datetime import timezone

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
db = SQLAlchemy(app)

class Spin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.Integer)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class SpinBackup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    result = db.Column(db.Integer)
    timestamp = db.Column(db.DateTime)
    backup_time = db.Column(db.DateTime)

@app.route('/')
def index():
    return render_template('index.html')

# Broken dublicate :/

#@app.route('/reset', methods=['POST']) 
#def reset_db():
#    conn = sqlite3.connect('roulette.db')
#    c = conn.cursor()
#    c.execute('DELETE FROM spins')
#    conn.commit()
#    conn.close()
#    return jsonify({'status': 'success'})

def get_db_connection():
    conn = sqlite3.connect("roulette.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/reset', methods=['POST'])
def reset_database_create_backup():
    spins = Spin.query.all()
    if spins:
        backup_time = datetime.now(timezone.utc)

        for spin in spins:
            backup = SpinBackup(
                result=spin.number,
                timestamp=spin.timestamp,
                backup_time=backup_time
            )
            db.session.add(backup)

        backup_data = [
            {
                "result": spin.number,
                "timestamp": spin.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            }
            for spin in spins
        ]
        filename = f"backup_spins_{backup_time.isoformat().replace(':', '-')}.json"
        with open(filename, 'w') as f:
            json.dump(backup_data, f, indent=2)

        for spin in spins:
            db.session.delete(spin)

        db.session.commit()

    return jsonify({"message": "Spins backed up and database reset."}), 200

@app.route('/spin', methods=['POST'])
def add_spin_legacy():
    number = int(request.json['number'])
    spin = Spin(number=number)
    db.session.add(spin)
    db.session.commit()
    return jsonify({'status': 'ok'})

@app.route('/spins', methods=['GET', 'POST'])
def handle_spins():
    if request.method == 'POST':
        data = request.get_json()
        if data and "result" in data:
            spin = Spin(number=int(data["result"]))
            db.session.add(spin)
            db.session.commit()
            return jsonify({
                "result": spin.number,
                "timestamp": spin.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            }), 201
        return jsonify({"error": "Invalid input"}), 400

    all_spins = Spin.query.order_by(Spin.timestamp).all()
    return jsonify([
        {
            "result": s.number,
            "timestamp": s.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }
        for s in all_spins
    ])

@app.route('/spins/<int:index>', methods=['DELETE'])
def delete_spin(index):
    spins = Spin.query.order_by(Spin.timestamp).all()
    if 0 <= index < len(spins):
        db.session.delete(spins[index])
        db.session.commit()
        return jsonify({
            "result": spins[index].number,
            "timestamp": spins[index].timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }), 200
    return jsonify({"error": "Index out of range"}), 404

@app.route('/stats')
def get_stats():
    spins = [s.number for s in Spin.query.order_by(Spin.timestamp).all()]
    number_freq, color_freq = calculate_frequencies(spins)
    entropy = calculate_entropy(spins)
    bankroll = simulate_martingale(spins)

    return jsonify({
        'number_freq': number_freq,
        'color_freq': color_freq,
        'entropy': entropy,
        'bankroll_over_time': bankroll
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)