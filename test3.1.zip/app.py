from flask import *
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import sqlite3
import json

# Import utility functions for analytics
from Utility_Math_Functions import (
    calculate_frequencies,
    calculate_entropy,
    simulate_martingale
)

# Initialize Flask app
app = Flask(__name__)

# Configure SQLite database using SQLAlchemy
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
db = SQLAlchemy(app)

# Define model for storing roulette spins
class Spin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.Integer)  # The number that was spun (0–36 typically)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)  # When the spin was recorded

# Define model for backing up spins before a reset
class SpinBackup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    result = db.Column(db.Integer)  # Backup of the spun number
    timestamp = db.Column(db.DateTime)  # When it was originally spun
    backup_time = db.Column(db.DateTime)  # When the backup was taken

# Route to render the homepage (e.g., index.html interface)
@app.route('/')
def index():
    return render_template('index.html')

# Optional: Connect to raw SQLite database (used only if bypassing SQLAlchemy)
def get_db_connection():
    conn = sqlite3.connect("roulette.db")
    conn.row_factory = sqlite3.Row
    return conn

# Broken dublicate :/

#@app.route('/reset', methods=['POST']) 
#def reset_db():
#    conn = sqlite3.connect('roulette.db')
#    c = conn.cursor()
#    c.execute('DELETE FROM spins')
#    conn.commit()
#    conn.close()
#    return jsonify({'status': 'success'})

# Route to reset all spins and create a backup (both in DB and JSON file)

@app.route('/reset', methods=['POST'])
def reset_database_create_backup():
    spins = Spin.query.all()

    if spins:
        # Use PC's local time instead of UTC
        backup_time = datetime.now()

        # Backup current spins into the database
        for spin in spins:
            backup = SpinBackup(
                result=spin.number,
                timestamp=spin.timestamp,
                backup_time=backup_time
            )
            db.session.add(backup)

        # Create a JSON backup file using local timestamp
        backup_data = [
            {
                "result": spin.number,
                "timestamp": spin.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            }
            for spin in spins
        ]
        filename = f"backup_spins_{backup_time.strftime('%Y-%m-%d_%H-%M-%S')}.json"
        with open(filename, 'w') as f:
            json.dump(backup_data, f, indent=2)

        # Clear all spins from the main table
        for spin in spins:
            db.session.delete(spin)

        db.session.commit()

    return jsonify({"message": "Spins backed up and database cleared."}), 200


# Legacy endpoint to add a single spin via POST (expects JSON with "number")
@app.route('/spin', methods=['POST'])
def add_spin_legacy():
    try:
        number = int(request.json['number'])  # Get number from request
    except (KeyError, ValueError, TypeError):
        return jsonify({'error': 'Invalid number'}), 400

    new_spin = Spin(number=number)
    db.session.add(new_spin)
    db.session.commit()

    return jsonify({'status': 'ok'})

# Endpoint to add or retrieve spins
@app.route('/spins', methods=['GET', 'POST'])
def handle_spins():
    if request.method == 'POST':
        data = request.get_json()

        # Validate input
        if not data or "result" not in data:
            return jsonify({"error": "Missing 'result' field"}), 400

        try:
            result = int(data["result"])
        except (ValueError, TypeError):
            return jsonify({"error": "Result must be an integer"}), 400

        # Create new spin
        spin = Spin(number=result)
        db.session.add(spin)
        db.session.commit()

        return jsonify({
            "result": spin.number,
            "timestamp": spin.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }), 201

    # If GET: return all spins in order
    spins = Spin.query.order_by(Spin.timestamp).all()
    return jsonify([
        {
            "result": spin.number,
            "timestamp": spin.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }
        for spin in spins
    ])

# Delete a spin by its index in the list (based on timestamp order)
@app.route('/spins/<int:index>', methods=['DELETE'])
def delete_spin(index):
    spins = Spin.query.order_by(Spin.timestamp).all()

    if 0 <= index < len(spins):
        spin_to_delete = spins[index]
        db.session.delete(spin_to_delete)
        db.session.commit()

        return jsonify({
            "result": spin_to_delete.number,
            "timestamp": spin_to_delete.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }), 200

    return jsonify({"error": "Invalid spin index"}), 404

# Route to compute stats from current spins
@app.route('/stats')
def get_stats():
    # Get list of numbers in spin history
    spins = [s.number for s in Spin.query.order_by(Spin.timestamp).all()]

    # Perform analytics using imported utils
    number_freq, color_freq = calculate_frequencies(spins)
    entropy = calculate_entropy(spins)
    bankroll = simulate_martingale(spins)

    return jsonify({
        'number_freq': number_freq,            # Frequency of numbers
        'color_freq': color_freq,              # Frequency of colors (e.g., red/black)
        'entropy': entropy,                    # Entropy (randomness measure)
        'bankroll_over_time': bankroll         # Martingale simulation results
    })

# Create database tables (if they don’t exist) and run the app
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
