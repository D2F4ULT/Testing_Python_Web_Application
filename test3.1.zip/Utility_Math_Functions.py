from collections import Counter
import math

def calculate_frequencies(spins):
    number_freq = {}
    for n in spins:
        if n in number_freq:
            number_freq[n] += 1
        else:
            number_freq[n] = 1
    total = len(spins)
    color_freq = {'red': 0, 'black': 0, 'green': 0}
    for n in spins:
        if n == 0:
            color_freq['green'] += 1
        elif n % 2 == 1:
            color_freq['red'] += 1
        else:
            color_freq['black'] += 1
    number_freq_pct = {}
    color_freq_pct = {}
    for k in number_freq:
        number_freq_pct[k] = number_freq[k] / total * 100
    for k in color_freq:
        color_freq_pct[k] = color_freq[k] / total * 100
    return number_freq_pct, color_freq_pct

def calculate_entropy(spins):
    total_spins = len(spins)
    
    if total_spins == 0:
        return 0.0
    
    spin_counts = Counter(spins)
    entropy = 0.0
    
    for spin_value in spin_counts:
        probability = spin_counts[spin_value] / total_spins
        entropy -= probability * math.log2(probability)
    
    return entropy

def simulate_martingale(spins, starting_money=1000, starting_bet=10):
    money = starting_money
    current_bet = starting_bet
    money_over_time = []

    for spin in spins:
        # If the spin is 0 or even, treat it as a loss
        if spin == 0 or spin % 2 == 0:
            money = money - current_bet
            current_bet = current_bet * 2
        else:
            # Win: add the bet and reset the bet amount
            money = money + current_bet
            current_bet = starting_bet

        # Stop if player runs out of money
        if money <= 0:
            money = 0
            money_over_time.append(money)
            break

        money_over_time.append(money)
    
    return money_over_time
